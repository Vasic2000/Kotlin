package su.vasic2000.kotlin.ui.base

open class BaseViewState<T>(val data: T, val error: Throwable?) {
}