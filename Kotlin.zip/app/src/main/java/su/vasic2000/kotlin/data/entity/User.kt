package su.vasic2000.kotlin.data.entity

data class User(val name: String, val email: String) {
}