package su.vasic2000.kotlin.data.errors
class NoAuthException: Throwable()
